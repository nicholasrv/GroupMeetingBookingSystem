package com.example.GroupMeetingBookingSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GroupMeetingBookingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
